<?php
  include_once("dbconnect.php");

  $recipient_name=$_POST["recipient_name"];
  $password=$_POST["password"];

  $sql="INSERT INTO login (recipient_name,password) VALUES ('".$recipient_name."','".$password."')";

  if(mysqli_query($conn,$sql)===TRUE)
  {
    header("location:index.html?Success");
  }
  else
  {
    header("location:index.html?Error");   
  }

  mysqli_close($conn);
?>