<?php
$name = "sdfds";

if(isset($name)){
    echo 'variable "name" is present';
} else {
    echo 'variable "name" is not present';
}