<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "studentexpo";

$conn = new mysqli($server, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
	header("Location:error.php?error=conn");
}