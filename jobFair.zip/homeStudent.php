<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location:studentLogin.php");
}
?>
<a href="logout.php">Logout</a>
<h1>Welcome home <?php echo $_SESSION['username']; ?> </h1>