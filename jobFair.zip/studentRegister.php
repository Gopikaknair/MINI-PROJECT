<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GFG- Store Data</title>
    </head>
    <body>
    <center>
        <?php if (isset($_GET['success'])) {
            echo "<h1>Student registered succesfully.</h1>";
        }
        if(isset($_GET['error'])){
           echo "<h1>Error is : ".$_GET['error']."</h1>"; 
        }
        ?>
        <h1>Storing Form data in Database</h1>
        <form action="studentRegisterAction.php" method="post">
            <table>
                <tr>
                    <td><label for="username"> Username:</label></td>
                    <td><input type="text" name="username" id="username"></td>
                </tr>
                <tr>
                    <td><label for="password">Password:</label></td>
                    <td><input type="password" name="password" id="password"></td>
                </tr>
                <tr>
                    <td><label for="confirmpassword">Confirm Password:</label></td>
                    <td><input type="password" name="confirmpassword" id="confirmpassword"></td>
                </tr>
                <tr>
                    <td><label for="name"> Full Name:</label></td>
                    <td> <input type="text" name="name" id="name"></td>
                </tr>
                <tr>
                    <td><label for="course">Course:</label></td>
                    <td>
                        <input type="radio" id="bcom" name="course" value="BCOM">
                        <label for="bcom">BCOM</label><br>
                        <input type="radio" id="bsc_cs" name="course" value="BSc_CS">
                        <label for="bsc_cs">BSc CS</label><br>
                        <input type="radio" id="eco" name="course" value="Economics">
                        <label for="eco">Economics</label><br>
                    </td>
                </tr>
                <tr>
                    <td><label for="regno">University Register Number:</label></td>
                    <td> <input type="text" name="regno" id="regno"></td>
                </tr>
                <tr>
                    <td><label for="batch_year">Year of Joining:</label></td>
                    <td> <input type="text" name="batch_year" id="batch_year"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Register"></td>
                </tr>
            </table>
        </form>
    </center>
</body>
</html>