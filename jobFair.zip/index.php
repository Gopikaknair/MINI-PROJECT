<html>
 <body>
  <a href="studentRegister.php">Student Registration</a><br>
  <a href="studentLogin.php">Student Login</a><br>
  <a href="user_login.php">User Login</a><br>
 </body>
</html>