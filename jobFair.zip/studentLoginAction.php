<?php

session_start();

include_once './dbconnect.php';
$username = $_POST['username'];
$password = $_POST['password'];

$query = "select username from login_student where username=? and password =?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ss', $username, $password);
if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $usernameExists = true;
        $_SESSION['username'] = $username;
        header("Location:homeStudent.php");
    } else {
        $error = urldecode("Invalid username or password");
        header("Location:studentLogin.php?error=" . $error);
    }
} else {
    $error = urldecode("Error");
    header("Location:studentLogin.php?error=" . $error);
}

