-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2023 at 04:51 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentexpo`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `idcourse` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`idcourse`, `name`, `status`) VALUES
(1, 'Computer Science', NULL),
(2, 'BCOM', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `interview_slot`
--

CREATE TABLE `interview_slot` (
  `idinterview_slot` int(11) NOT NULL,
  `idlogin_student` int(11) NOT NULL,
  `idvaccancy` int(11) NOT NULL,
  `requested_time` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_time` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `slot_selected_start` datetime DEFAULT NULL,
  `slot_selected_end` datetime DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '0- deleted\n1- waiting for approval\n2 - approved\n3- attended',
  `selected` tinyint(4) DEFAULT 0 COMMENT '0- rejected\n1- selected\n2 - wating list',
  `notes` text DEFAULT NULL COMMENT 'notes  for company'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_interview`
--

CREATE TABLE `job_interview` (
  `idvaccancy` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `batch_year_start` int(11) DEFAULT NULL,
  `batch_year_end` int(11) DEFAULT NULL,
  `course_id` text DEFAULT NULL,
  `date_interview` datetime DEFAULT NULL,
  `date_interview_end` datetime DEFAULT NULL,
  `time_start` time DEFAULT NULL,
  `time_end` time DEFAULT NULL,
  `interviewtime` int(11) DEFAULT NULL COMMENT 'time required for one interview in mins.',
  `approved_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '0- deleted\n1- requested\n2- approved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_student`
--

CREATE TABLE `login_student` (
  `idlogin_student` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `created_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `login_student`
--

INSERT INTO `login_student` (`idlogin_student`, `username`, `password`, `status`, `created_on`) VALUES
(1, '370992428523', 'asdfgh', 1, '2023-01-19 22:28:15'),
(2, '3709924228523', 'asdfgh', 1, '2023-01-19 22:39:03'),
(3, '3709924285238', 'kjhgfd', 1, '2023-01-19 22:50:53'),
(5, '101', 'kjhgf', 1, '2023-01-19 22:54:16'),
(6, '789', 'asdfg', 1, '2023-01-19 23:09:50'),
(7, 'asdfghjkl', 'poiu', 1, '2023-01-21 20:11:36'),
(8, 'mnbvc', 'mnbvc', 1, '2023-01-24 21:07:56'),
(10, 'mnbvcqwrt', 'qwerty', 1, '2023-01-24 21:10:10');

-- --------------------------------------------------------

--
-- Table structure for table `login_user`
--

CREATE TABLE `login_user` (
  `idlogin_user` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `role` int(11) DEFAULT 1 COMMENT '1 - hr\n2 - company\n3- admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `login_user`
--

INSERT INTO `login_user` (`idlogin_user`, `username`, `password`, `name`, `status`, `role`) VALUES
(1, 'admin@admin.com', NULL, 'admin', 1, 3),
(2, '20040BS36010', 'adsfgh', 'aswathy raj', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE `resume` (
  `idresume` int(11) NOT NULL,
  `idlogin_student` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '-1 - rejected\n0- deleted\n1 - wating for approval\n2 - approved',
  `approved_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT current_timestamp(),
  `last_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_profile`
--

CREATE TABLE `student_profile` (
  `idstudent_profile` int(11) NOT NULL,
  `idlogin_student` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `batch_year` int(11) DEFAULT NULL COMMENT 'joining year',
  `course_idcourse` int(11) NOT NULL,
  `profile_img` varchar(200) DEFAULT NULL,
  `regno` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `student_profile`
--

INSERT INTO `student_profile` (`idstudent_profile`, `idlogin_student`, `name`, `batch_year`, `course_idcourse`, `profile_img`, `regno`) VALUES
(1, 2, 'asdfghjkl', 2020, 1, NULL, '65656565'),
(2, 6, 'Greena', 2121, 1, NULL, '8523647965');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`idcourse`);

--
-- Indexes for table `interview_slot`
--
ALTER TABLE `interview_slot`
  ADD PRIMARY KEY (`idinterview_slot`),
  ADD KEY `fk_interview_slot_login_student1_idx` (`idlogin_student`),
  ADD KEY `fk_interview_slot_job_interview1_idx` (`idvaccancy`),
  ADD KEY `fk_interview_slot_login_user1_idx` (`approved_by`);

--
-- Indexes for table `job_interview`
--
ALTER TABLE `job_interview`
  ADD PRIMARY KEY (`idvaccancy`),
  ADD KEY `fk_job_interview_login_user1_idx` (`approved_by`);

--
-- Indexes for table `login_student`
--
ALTER TABLE `login_student`
  ADD PRIMARY KEY (`idlogin_student`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `login_user`
--
ALTER TABLE `login_user`
  ADD PRIMARY KEY (`idlogin_user`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`);

--
-- Indexes for table `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`idresume`),
  ADD KEY `fk_resume_login_student1_idx` (`idlogin_student`),
  ADD KEY `fk_resume_login_user1_idx` (`approved_by`);

--
-- Indexes for table `student_profile`
--
ALTER TABLE `student_profile`
  ADD PRIMARY KEY (`idstudent_profile`),
  ADD KEY `fk_student_profile_login_student_idx` (`idlogin_student`),
  ADD KEY `fk_student_profile_course1_idx` (`course_idcourse`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `idcourse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `interview_slot`
--
ALTER TABLE `interview_slot`
  MODIFY `idinterview_slot` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_interview`
--
ALTER TABLE `job_interview`
  MODIFY `idvaccancy` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_student`
--
ALTER TABLE `login_student`
  MODIFY `idlogin_student` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login_user`
--
ALTER TABLE `login_user`
  MODIFY `idlogin_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `resume`
--
ALTER TABLE `resume`
  MODIFY `idresume` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_profile`
--
ALTER TABLE `student_profile`
  MODIFY `idstudent_profile` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `interview_slot`
--
ALTER TABLE `interview_slot`
  ADD CONSTRAINT `fk_interview_slot_job_interview1` FOREIGN KEY (`idvaccancy`) REFERENCES `job_interview` (`idvaccancy`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_interview_slot_login_student1` FOREIGN KEY (`idlogin_student`) REFERENCES `login_student` (`idlogin_student`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_interview_slot_login_user1` FOREIGN KEY (`approved_by`) REFERENCES `login_user` (`idlogin_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `job_interview`
--
ALTER TABLE `job_interview`
  ADD CONSTRAINT `fk_job_interview_login_user1` FOREIGN KEY (`approved_by`) REFERENCES `login_user` (`idlogin_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `resume`
--
ALTER TABLE `resume`
  ADD CONSTRAINT `fk_resume_login_student1` FOREIGN KEY (`idlogin_student`) REFERENCES `login_student` (`idlogin_student`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_resume_login_user1` FOREIGN KEY (`approved_by`) REFERENCES `login_user` (`idlogin_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `student_profile`
--
ALTER TABLE `student_profile`
  ADD CONSTRAINT `fk_student_profile_course1` FOREIGN KEY (`course_idcourse`) REFERENCES `course` (`idcourse`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_student_profile_login_student` FOREIGN KEY (`idlogin_student`) REFERENCES `login_student` (`idlogin_student`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
