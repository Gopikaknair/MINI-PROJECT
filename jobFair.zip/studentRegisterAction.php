<!DOCTYPE html>
<html>
    <head>
        <title>Insert Page page</title>
    </head>
    <body>
    <center>
        <?php
        include_once("dbconnect.php");
//        if(!isset($_POST['username'],$_POST['password'],$_POST['course'])){
//            $error = urlencode("Missing parameter");
//             header("Location:studentRegister.php?error=" . $error);
//        }
        
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $course_idcourse = $_POST['course'];
        $regno = $_POST['regno'];
        $batchYear = $_POST['batch_year'];
        
        //error checking
       
        

        //check if username already exists.
        $query = "select * from login_student where username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $usernameExists = true;
            }
        }

        if (isset($usernameExists)) {
            $error = urlencode("username already exist!");
            header("Location:studentRegister.php?error=" . $error);
        } else {
            //start inserting into student login table
            $query = "INSERT INTO login_student (username,password)  VALUES (?,?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $username, $password);
            if ($stmt->execute()) {
                //start inserting into student profile table
                $id = $stmt->insert_id;
                $query = "INSERT INTO `student_profile` ( `idlogin_student`, `name`, `batch_year`, `course_idcourse`, `profile_img`, `regno`) " .
                        "VALUES (?,?,?,?,?,?) ";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("isiiss", $id, $name, $batchYear, $course_id, $profileImg, $regno);
                $course_id = 1;
                $profileImg = "";
                if ($stmt->execute()) {
                    $id = $stmt->insert_id;
                    header("Location:studentRegister.php?success=" . $id);
                } else {
                    header("Location:studentRegister.php?error");
                }
            } else {
                header("Location:studentRegister.php?error");
            }
        }

        $conn->close();
        ?>

    </center>
</body>
</html>