<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location:homeStudent.php");
}
?>
<!DOCTYPE html>

<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
    <center>
        <h1>Student Login Form</h1>
        <?php
        if (isset($_GET['error'])) {
            echo "<h3 style=\"color: red;\">" . $_GET['error'] . "</h3>";
        }
        ?>
        <form  action="studentLoginAction.php"  method="post">
            <table>
                <tr>
                    <td>username : </td>
                    <td><input type="text" name="username"></td>
                </tr>
                <tr>
                    <td>Password : </td>
                    <td><input type="password" name="password"></td>
                </tr>
                <tr><td></td><td><input type="submit" name="submit" value="Login"></td></tr>

            </table>
        </form>
    </center>
</body>
</html>
