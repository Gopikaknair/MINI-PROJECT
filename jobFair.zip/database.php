<?php


$server = "localhost";
$username = "root";
$password = "";
$db = "test";

$con = new mysqli($server, $username, $password, $db);

// Check connection
if ($con->connect_error) {
	header("Location:error.php?error=con");
}

//insert 
$name = "test122";
$address = "address 1";
$status = "1";

$query = "INSERT INTO `table1` ( `name`, `address`, `status`) VALUES (?, ?, ?)";
$stmt = $con->prepare($query);
$stmt->bind_param("sss",$name, $address, $status);
/*
Character	Description - bind_param string type.
i	corresponding variable has type int
d	corresponding variable has type float
s	corresponding variable has type string
b	corresponding variable is a blob and will be sent in packets
*/
echo "<h2>Insert query out</h2>";
if($stmt->execute()){
	echo '<br>Inserted into table with primary key '.$stmt->insert_id;
}else{
	echo '<br>Error in inserting to table';
}


//__________________________________________________________________________________________
//select
echo "<h2>Select query out</h2>";
$query = "SELECT * FROM table1 where status = ?";
$stmt = $con->prepare($query);
$stmt->bind_param("s",$status);
$status = "1";
$stmt->execute();
$result = $stmt->get_result();

echo "<table border=\"1\"><th><td>Id</td><td>Name</td><td>address</td></th>";
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
	echo "<tr>";
    echo "<td>" . $row["id"]. "</td><td>" . $row["name"]. "</td><td>" . $row["address"]. "</td>";
	echo "</tr>";
  }
} else {
  echo "<tr colspan=\3\"><td>0 results</td></tr>";
}
echo "</table><br>";

//__________________________________________________________________________________________
//delete
echo "<h2>Delete query out</h2>";
$query = "DELETE from `table1` where status !=?";
$stmt = $con->prepare($query);
$stmt->bind_param("s",$status);
$status = "1";

if($stmt->execute()){
	$count = $stmt->affected_rows;
	echo '<br>Deleted rows count '.$count;
}else{
	echo '<br>Error in Deleting';
}


//__________________________________________________________________________________________
//update
echo "<h2>Update query out</h2>";
$query = "update`table1` set status = ? where status =?";
$stmt = $con->prepare($query);
$stmt->bind_param("ss",$statusUpdate,$status);
$status = "1";
$statusUpdate = "0";

if($stmt->execute()){
	$count = $stmt->affected_rows;
	echo '<br>updated rows count '.$count;
}else{
	echo '<br>Error in updating';
}

