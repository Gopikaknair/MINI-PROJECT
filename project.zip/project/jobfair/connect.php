<?php

  $conn = mysqli_connect("localhost", "root", "", "jobfair");
// Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // Taking all 5 values from the form data(input)
        $recipient_name = $_POST["recipient_name"];
        $password = $_POST["password"];
        /*$gender =  $_REQUEST['gender'];
        $address = $_REQUEST['address'];
        $email = $_REQUEST['email'];*/
         
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO login VALUES ('$recipient_name','$password')";
         
        if(mysqli_query($conn, $sql)===true){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";
 
            echo nl2br("$recipient_name\n " . "$password\n");
        } else{
            echo "ERROR: Hush! Sorry $sql. " . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
?>