<?php
include_once("dbconnect.php");


 
 //echo "Connected successfully<br>";
 $id=$_POST["id"];
 $name=$_POST["name"];
 $sql = "INSERT INTO nametbl  VALUES ('$id' , '$name')";

 if(mysqli_query($conn, $sql)===TRUE){
            /*echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";}*/
            header("location:registration.php?Success=1");}
            else
            {header("location:registration.php?Success=0");}

 mysqli_close($conn);
?>