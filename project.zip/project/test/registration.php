<html>
<head>
	<title>Registration Form</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
    <h2>Registration Form</h2>
    <?php if(isset($_GET["Success"])){
      if($GET["Success"]==1){
        echo "<h3>Successful</h3>";
      }
      else{
        echo "<h3>Not Successful</h3>";
      }
    }
    ?>
    <form action="registration_form.php" method="POST"> 
    ID: <input type="number" name="id"> <br><br>
    Name: <input type="text" name="name"> <br><br>
        <input type="submit" value="Submit">        
      </form>
</body>
</html>