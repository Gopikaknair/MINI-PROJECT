<?php
$conn=mysqli_connect('localhost','root','','jbfairtest');
if(!$conn)
 { header('Location: noconnection.php');
   //die("Connection failed:".mysqli_connect_error());
 }
